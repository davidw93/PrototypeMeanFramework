#!perl -w

use SOAP::Lite;

my $s = SOAP::Lite 
 -> uri('urn:nirvanasRealm') 
 -> proxy('http://localhost:80/soap/');

my $chancount = $s->getChannelCount()->result;
print "Channel Count is $chancount";

