This directory contains some examples on accessing Nirvana functionality using the SOAP Plugin on an NHP interface.
The samples included use the SOAP::Lite perl module and assume that there is an NHP interface running on port 80 on the localhost.
You can easily modify them to access a realm in a different location.
