#!perl -w

use SOAP::Lite;

on_fault => sub { my($s, $result) = @_;
      die ref $result ? $result->faultstring : $s->transport->status, "\n";
};
my $s = SOAP::Lite
 -> uri('urn:nirvanasChannel')
 -> proxy('http://localhost:80/soap/');

my $lval = SOAP::Data->type(long => 0);
my @details = $s->getEvents('/test', 1, $lval)->result;
for $i (0 .. $#details) {
 for $j (0 .. $#{$details[$i]}) {
  print "---------------------------------\n";
  for $role ( keys %{ $details[$i][$j] } ) {
    print "$role=$details[$i][$j]{$role}\n";
  }
 }
}
