#!perl -w

use SOAP::Lite;

on_fault => sub { my($s, $result) = @_;
      die ref $result ? $result->faultstring : $s->transport->status, "\n";
    };

my $s = SOAP::Lite
 -> uri('urn:nirvanasChannel')
 -> proxy('http://localhost:80/soap/');

my $ec = $s->getEventCount('/testp')->result;
print "EventCount :  $ec";
