#!perl -w

use SOAP::Lite;

my $s = SOAP::Lite
 -> uri('urn:nirvanasRealm')
 -> proxy('http://localhost:80/soap/');

my @details = $s->getChannelDetails('/')->result;

for $i (0 .. $#details) {
 for $j (0 .. $#{$details[$i]}) {
  print "---------------------------------\n";
  for $role ( keys %{ $details[$i][$j] } ) {
    print "$role=$details[$i][$j]{$role}\n";
  }
 }
}
