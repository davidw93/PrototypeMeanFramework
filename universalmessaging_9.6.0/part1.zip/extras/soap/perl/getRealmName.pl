#!perl -w

use SOAP::Lite;

my $s = SOAP::Lite 
 -> uri('urn:nirvanasRealm') 
 -> proxy('http://localhost:80/soap/');

my $realmName = $s->getRealmName()->result;
print "RealmName is $realmName";

