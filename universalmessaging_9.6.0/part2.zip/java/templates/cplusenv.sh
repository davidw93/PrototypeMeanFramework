#!/bin/sh
#  ----------------------------------------------------------------------------------
# LEGAL NOTICES
# 
# This notice is valid for all products, product lines and associated products
# of Software AG comprising software, documentation, user manuals and other
# related materials in tangible or electronic form (the "Product").
# �You� and �your� refers to the individual or entity that has executed a license agreement pursuant to the provisions of Part B, Part C or Part D and that uses the Product. 
# 
# IMPORTANT: PLEASE READ BEFORE INSTALLING THE PRODUCT
# 
# 
# PART A: GENERAL TERMS
# 
# You are not allowed to install or use the Product without a corresponding
# license agreement.
# 
# If You have entered into a commercial license agreement with one of
# Software AG's subsidiaries or distributors ("Commercial License Agreement")
# the installation and use of the Product is subject to your acceptance of
# additional terms which are provided for You in "Part B: Additional Terms".
# 
# If You have not entered into a Commercial License Agreement and You have
# been granted access to a webMethods Partner Server by a sponsoring company
# that has licensed a Software AG webMethods solution, You must execute the
# license agreement with Software AG which is provided for You in "Part C:
# Software AG License Agreement for webMethods Partner Servers Only"
# 
# If You have not entered into a Commercial License Agreement and You are
# not using a webMethods Partner Server pursuant to Part C, You must execute
# the license agreement with Software AG which is provided for You in "Part D
# Software AG Evaluation License Agreement for Trial Versions of Software AG
# Products" ONLY.
# 
# EXPORT CONTROL REGULATIONS 
# Selecting the <"Submit" | �I agree� | �OK�> button after having checked the �Yes, I accept the License Agreement and the Export Regulation.� checkbox is your confirmation that You agree to and comply with each of the following statements, now and during the trial term: 
# - You are NOT a citizen, national, or resident of, and are not under control of, the government of Cuba, Iran, North Korea, Sudan, Syria, nor any country to which the European Union (EU) or the United States have prohibited export. 
# - You will NOT download or otherwise export or re-export the Software Applications, directly or indirectly, to the above mentioned countries nor to citizens, nationals or residents of those countries. 
# - You are NOT listed on the European Union�s �Consolidated List of persons, groups and entities subject to EU financial sanctions� or on the United States Department of Treasury lists of �Specially Designated Nationals�, �Specially Designated Terrorists�, and �Specially Designated Narcotic Traffickers�, nor are You or your company listed on the United States Department of Commerce �Table of Denial Orders� (i.e. �Denied Persons List�) or the Entity List (-> Supplement No. 4 to EAR �744 (US Export Administration Regulations)). 
# - You will NOT download or otherwise export or re-export the Software Applications, directly or indirectly, to persons on the above mentioned lists. 
# - You will NOT use the Software Applications for, and will not allow the Software Applications to be used for, any purposes prohibited by European or United States laws, including, without limitation, for the development, design, manufacture or production of nuclear, chemical or biological weapons of mass destruction.
# 
# COPYRIGHT AND TRADEMARK NOTICE
# 
# The name Software AG, webMethods and all Software AG product names are either
# trademarks or registered trademarks of Software AG and/or Software AG USA,
# Inc. Other company and product names mentioned herein may be trademarks of
# their respective owners.
# 
# Other brands or names mentioned may be trademarks or registered trademarks
# of their respective owners.
# 
# Software AG or its subsidiaries are the sole owner of all intellectual
# property rights to the Products and accompanying user documentation or have
# the respective distribution rights. References made in or on the Products to
# the copyright and/or to the industrial property rights must not be altered,
# deleted or obliterated in any manner.
# 
# No right, title or interest in any trademark or trade names of Software AG
# or its subsidiaries or its licensors is granted hereunder.
# 
# (c) Copyright 2012 Software AG, Darmstadt, Germany and/or Software AG USA
# Inc., Reston, United States of America, and/or their licensors.
# 
# 
# PART B: ADDITIONAL TERMS COMMERCIAL LICENSE
# 
# The Commercial License Agreement does not grant You the right to sublicense,
# rent, assign or lease the software, in whole or in part, and You may not
# decompile, disassemble, modify, decrypt, extract or otherwise reverse engineer,
# or make further copies of the software, except as explicitly permitted by
# the Commercial License Agreement.
# 
# Also, the Product contains certain third party technology that is not designed
# or intended for use in on-line control of aircraft, air traffic, aircraft
# navigation or aircraft communications; or in the design, construction,
# operation or maintenance of any nuclear facility. You must not use or
# redistribute the Product for such purposes.
# 
# EXPORT RESTRICTIONS
# You agree that U.S. export control law and other applicable export and import law provisions govern your use of the Software Applications and/or Technology, including technical assistance and technical data (as defined under �Technology� in the Definitions section of the EAR, �722.1); 
# You further agree not to download and/or otherwise export or re-export directly, or indirectly, any underlying licensed items (i.e. Software, Technology, any direct product thereof, or other information from the Licensed Software), except as stated explicitly in this Agreement and in full compliance with all applicable national and international export- and other laws and regulations, or not to use these items for any purpose prohibited by said laws, including, without limitation, nuclear, chemical, or biological weapons proliferation.
# You also agree to indemnify and hold harmless and defend SOFTWARE AG against any and all liability arising from, or relating to your breach of this Section.
# 
# If applicable, You will find specific terms in addition to your commercial
# license agreement for the use of this product in Part E.
# 
# 
# PART C:  SOFTWARE AG LICENSE AGREEMENT FOR WEBMETHODS PARTNER SERVERS ONLY
# 
# IMPORTANT:  THIS AGREEMENT APPLIES ONLY IF YOU ARE USING A WEBMETHODS PARTNER
# SERVER PROVIDED BY A SPONSORING COMPANY THAT HAS LICENSED A SOFTWARE AG
# WEBMETHODS SOLUTION.  THE TERMS OF THIS AGREEMENT DO NOT APPLY IF YOU
# HAVE ALREADY EXECUTED A COMMERCIAL LICENSE AGREEMENT FOR THE WEBMETHODS
# PARTNER SERVER WITH A SOFTWARE AG SUBSIDIARY OR DISTRIBUTOR.  PLEASE READ
# THIS AGREEMENT CAREFULLY BEFORE IN ANY WAY INSTALLING, ACCESSING, OR USING
# THE PRODUCT.
# 
# SOFTWARE AG LICENSE AGREEMENT FOR WEBMETHODS PARTNER SERVERS
# By installing the Product, You, as licensee, are entering into an agreement
# with Software AG, as licensor, with GENERAL TERMS as defined in Part A,
# as well as with terms set forth below in Part C.  In case of conflicting
# terms between Part A and the Part C, the terms of this Part C shall apply.
# If You do not agree to the terms of this Agreement, You must immediately,
# and in any case before installation, destroy the Product and all copies of
# the Product in physical, electronic or other form.  By installing and/or
# using the Product, You agree to be bound by and manifest your assent to all
# the terms and conditions of this Part C.
# 
# LICENSE GRANT
# Subject to the terms and conditions set forth in this Agreement, Software AG
# hereby grants to Licensee a nontransferable, non-sublicensable, nonexclusive,
# limited license during the Term to use the webMethods Partner Server and any
# other associated Software AG software program(s) made available to Licensee
# (the "Software"), in Executable Code form, together with the Documentation.
# This Agreement only grants Licensee the right to use the Software on one
# (1) designated CPU and to make one (1) copy of the Software for backup and
# archival purposes.  All use of the Software is strictly limited to Licensee's
# internal data processing in connection with the Software AG webMethods solution
# licensed to the sponsoring company and is strictly limited to bi-directional
# delivery of data between Licensee and such sponsoring company.  Any and
# all other use of the Software is strictly prohibited.  For purposes of this
# Agreement, the term (i) "Documentation" means the user manuals made available
# to Licensee in connection with the Software; and (ii) the term "Executable
# Code" means the fully compiled version of a software program that can be
# executed by a computer and used by an end user without further compilation.
# 
# PROPRIETYARY RIGHTS
# a.  Licensee acknowledges and agrees that the Software, Documentation, and
# all other related information and materials (collectively, the "Proprietary
# Information") provided to or made available to Licensee, and all patents,
# copyrights, trade secrets, and other United States or international
# intellectual property rights (each, an "Intellectual Property Right")
# embodied in the foregoing, are the exclusive and proprietary property of
# Software AG and/or its suppliers.  Licensee further acknowledges and agrees
# that the Software and its structure, underlying concepts, organization,
# and source code constitute valuable trade secrets of Software AG and/or its
# suppliers.  Accordingly, Licensee agrees not to (a) disassemble, reverse
# engineer, reverse compile, or otherwise attempt to derive the source code
# for the Software in whole or in part, (b) modify, adapt, alter, translate,
# or create derivative works from the Software; (c) merge the Software with
# other software; (d) sublicense, lease, rent, loan, or otherwise transfer
# the Software to any third party; or (e) except as expressly set forth in
# this Agreement, otherwise use, provide access to, or copy the Software.
# b.  Licensee shall keep the Proprietary Information in strict confidence and
# use the Property Information solely for purposes of exercising the license
# rights set forth in Section 1 of this Agreement.  Licensee shall restrict
# access to the Proprietary Information to only those authorized persons with
# a need to know in order for Licensee to exercise the license rights granted
# under Section 1 and shall ensure that all such authorized persons shall
# refrain from any disclosure, use, duplication, or reproduction prohibited by
# this Section 2.  Except as expressly set forth in this Agreement, Licensee
# shall not, directly or indirectly, use, disclose, distribute, duplicate,
# or otherwise reproduce the Proprietary Information, in whole or in part.
# Licensee agrees not to remove any copyright notice or other proprietary
# markings from the Proprietary Information or any copies thereof.
# c.  Licensee shall have no obligation to preserve the proprietary nature
# of only that portion of the Software AG's Proprietary Information that is
# or becomes generally available to the public by other than unauthorized
# disclosure.  In the event Licensee is required to disclose Proprietary
# Information by law or by any governmental agency having jurisdiction pursuant
# to an order to produce, or in the course of a legal proceeding pursuant to
# a lawful request for discovery, Licensee may disclose only that portion
# of the Proprietary Information that it is legally required to disclose;
# provided Licensee promptly notifies Software AG and reasonably cooperates
# with Software AG if Software AG's elects, at its expense, to seek to limit or
# avoid such disclosure by any lawful means and Licensee takes all reasonable
# and necessary actions to protect the confidentiality of the Proprietary
# Information disclosed.
# d.  Licensee agrees not to challenge, directly or indirectly, the right, title,
# and interest of Software AG in and to the Software or any other Proprietary
# Information, or any Intellectual Property Rights therein, nor the validity
# or enforceability of Software AG's rights under applicable law.  Licensee
# agrees not to, directly or indirectly, register, apply for registration,
# or attempt to acquire any legal protection for the Software or any other
# Proprietary Information, or any Intellectual Proprietary Rights therein,
# or to take any other action which may adversely affect Software AG's rights,
# title, or interest in or to the Software or any other Proprietary Information
# in any jurisdiction.
# e.  Licensee agrees to notify Software AG immediately and in writing of all
# circumstances surrounding the unauthorized possession or use of the Software
# or any other Proprietary Information by any person or entity.  Licensee agrees
# to cooperate fully with Software AG in any litigation relating to or arising
# from such unauthorized possession or use.
# f.  Licensee acknowledge that the Proprietary Information is unique and
# that Licensee's failure to comply with the provisions of this Section 2 may
# result in irreparable harm to Software AG and, in the event of the breach
# or threatened breach by Licensee of its obligations under this Section 2,
# Software AG shall be entitled to equitable relief in the form of specific
# performance and/or an injunction for any such actual or threatened breach,
# in addition to the exercise of any other remedies at law and in equity.
# g.  Software AG reserves all rights regarding the Software and all other
# Proprietary Information owned or licensed by Software AG to the extent such
# rights are not expressly granted to Licensee in this Agreement.
# 
# TERM AND TERMINATION
# Subject to Licensee's strict compliance with the terms and conditions of this
# Agreement, the term of this Agreement ("Term") shall be coincident with the
# term of the license granted to the sponsoring company for the Software AG
# webMethods solution.  This Agreement shall remain in effect until the Term
# expires or is terminated or this Agreement is otherwise terminated by Software
# AG for Licensee's breach of any of the provisions of this Agreement.  Upon the
# termination or expiration of this Agreement for any reason, all license rights
# granted under this Agreement shall immediately cease to exist and Licensee
# shall immediately discontinue all use of the Software and shall, within ten
# (10) days after the expiration or termination, certify in writing to Software
# AG that the Software and Documentation and all copies and related materials in
# the possession of Licensee have been removed from its system and destroyed.
# Notwithstanding any other provision of this Agreement, all of Licensee's
# obligations under this Agreement shall continue perpetually and irrevocably.
# 
# SUPPORT AND MAINTENANCE
# Software AG, in its sole discretion, may provide (and subsequently cease
# providing) Licensee with limited support and maintenance services for
# the Software.  Notwithstanding any decision by Software AG to exercise
# its discretion in providing Licensee with such services, in no event shall
# Licensee be deemed entitled to any support or maintenance or other similar
# services from Software AG, including but not limited to any fixes, updates,
# or new releases of the Software.
# 
# DISCLAIMER OF WARRANTIES
# ALL SOFTWARE, DOCUMENTATION, INFORMATION, MATERIALS AND/OR SERVICES PROVIDED
# TO LICENSEE IN CONNECTION WITH THIS AGREEMENT ARE PROVIDED "AS IS, WITH ALL
# FAULTS." SOFTWARE AG DOES NOT WARRANT THAT SOFTWARE WILL OPERATE UNINTERRUPTED
# OR ERROR FREE, THAT THE FUNCTIONS CONTAINED IN THE SOFTWARE WILL FUNCTION
# WITH OTHER SOFTWARE, HARDWARE, OR WITHIN A SYSTEM, OR THAT THE SOFTWARE,
# DOCUMENTATION, INFORMATION, MATERIALS AND/OR SERVICES PROVIDED PURSUANT TO
# THIS AGREEMENT WILL FULFILL ANY OF LICENSEE'S PARTICULAR PURPOSES OR NEEDS.
# WITHOUT LIMITING THE GENERALITY OF THE FOREGOING, SOFTWARE AG SPECIFICALLY
# DISCLAIMS ALL WARRANTIES, EXPRESS, STATUTORY, AND IMPLIED, INCLUDING,
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF ACCURACY, QUIET ENJOYMENT,
# NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.
# 
# LIMITATIONS OF LIABILITY
# NEITHER SOFTWARE AG NOR ANY OF ITS SUPPLIERS SHALL BE LIABLE TO LICENSEE OR ANY
# OTHER PARTY FOR ANY LOSS OR DAMAGE THAT ARISES IN CONNECTION WITH LICENSEE'S
# USE OF THE SOFTWARE OR THAT OTHERWISE ARISES FROM OR RELATES IN ANY WAY TO
# THIS AGREEMENT, INCLUDING, BUT NOT LIMITED TO, ANY MONETARY DAMAGES OR ANY
# DIRECT, INDIRECT, SPECIAL, INCIDENTAL, PUNITIVE, OR CONSEQUENTIAL DAMAGES,
# REGARDLESS OF THE FORM OF ACTION ALLEGED, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGES.  IN NO EVENT SHALL LICENSEE BE ENTITLED TO OBTAIN SPECIFIC
# PERFORMANCE IN CONNECTION WITH THIS AGREEMENT.  Licensee acknowledges that
# the limitations of liability and the disclaimer of warranties set forth in
# this Agreement constitute a fundamental basis of this Agreement and form the
# primary consideration between the parties and that Software AG would not have
# entered into this Agreement nor provided Licensee with access to the Software
# without such limitations of liability and the disclaimer of warranties.
# 
# EXPORT RESTRICTIONS
# You agree that U.S. export control law and other applicable export and import law provisions govern your use of the Software Applications and/or Technology, including technical assistance and technical data (as defined under �Technology� in the Definitions section of the EAR, �722.1); 
# You further agree not to download and/or otherwise export or re-export directly, or indirectly, any underlying licensed items (i.e. Software, Technology, any direct product thereof, or other information from the Licensed Software), except as stated explicitly in this Agreement and in full compliance with all applicable national and international export- and other laws and regulations, or not to use these items for any purpose prohibited by said laws, including, without limitation, nuclear, chemical, or biological weapons proliferation.
# You also agree to indemnify and hold harmless and defend SOFTWARE AG against any and all liability arising from, or relating to your breach of this Section.
# 
# MISCELLANEOUS
# Assignment.  Licensee may not assign or transfer this Agreement, or any rights
# or obligations hereunder (including the license rights), or the Software,
# in whole or part, whether by operation of law, change of control, or in any
# other manner.  Any assignment or attempted assignment in violation of the
# foregoing shall be null and void.  Software AG may assign any or all of its
# rights and obligations under this Agreement.
# Audit.  Licensee will reasonably cooperate with Software AG and provide
# Software AG with reasonable access to Licensee's information, facilities,
# and systems to enable Software AG to ensure Licensee's compliance with the
# terms of this Agreement.
# Jurisdiction.  This Agreement will be governed by and construed in accordance
# with the substantive laws in force: (a) in the Commonwealth of Virginia,
# if a license to the Software is obtained when Licensee is in the United
# States, Canada, Mexico, or any other country not described in subsections
# (b) and (c) below; (b) in Japan, if a license to the Software is obtained
# when Licensee is in Japan, China, Korea, or other southeast Asian country
# where the official languages are written in either an ideographic script
# (e.g., hanzi, kanji, or hanja) and/or other script based upon or similar
# in structure to an ideographic script (e.g., hangul or kana); or (c) the
# United Kingdom, if a license to the Software is obtained when Licensee is
# in any European Union country.  This Agreement will not be governed by the
# conflict of law rules of any jurisdiction or the United Nations Convention
# on Contracts for the International Sale of Goods, the application of which
# are expressly excluded.
# Severability.  If any provision of this Agreement is determined by a court
# of competent jurisdiction to be or becomes unenforceable or illegal, such
# provision shall be adjusted to the minimum extent necessary to cure such
# unenforceability or illegality and the remainder of this Agreement shall
# remain in effect in accordance with its terms as modified by such adjustment.
# U.S. Government Procurement.  If the Software is being acquired by or
# on behalf of the U.S. Government by a U.S. Government prime contractor
# or subcontractor (at any tier), then the U.S. Government's rights in the
# Software and accompanying Documentation will be only as set forth in this
# Agreement; this is in accordance with 48 CFR 227.7201 through 227.7202-4
# (for Department of Defense ("DOD") acquisitions) and with 48 CFR 2.101 and
# 12.212 (for non-DOD acquisitions).
# Waiver.  No waiver or retraction of a waiver under this Agreement shall be
# valid or binding unless set forth in writing and executed by a duly authorized
# representative of the party against whom such waiver is sought.  The failure
# of either party to exercise any right granted herein, or to require the
# performance by the other party of any obligation set forth herein, or the
# waiver by either party of any breach of this Agreement, will not prevent a
# subsequent exercise or enforcement of such provisions or be deemed a waiver
# of any subsequent breach of the same or any other provision of this Agreement.
# Integration.  This Agreement constitutes the entire agreement between
# the parties regarding the subject hereof and supersedes all prior and
# all contemporaneous agreements, understandings, marketing materials, and
# communications, whether written or oral.  Any modification or amendment of
# any provision of this Agreement must be in writing and bear the signature
# of the duly authorized representative of each party.  Neither the course of
# conduct between the parties nor trade usage will act to modify this Agreement.
# 
# 
# PART D: SOFTWARE AG EVALUATION LICENSE AGREEMENT FOR TRIAL VERSIONS OF
# SOFTWARE AG PRODUCT ONLY
# 
# IMPORTANT: PLEASE READ THIS SOFTWARE AG EVALUATION LICENSE AGREEMENT CAREFULLY
# BEFORE INSTALLING THE PRODUCT! THE TERMS OF THIS EVALUATION LICENSE AGREEMENT
# APPLY ONLY IF YOU HAVE NOT ALREADY EXECUTED A COMMERCIAL LICENSE AGREEMENT
# WITH A SOFTWARE AG SUBSIDIARY OR DISTRIBUTOR.
# 
# EVALUATION LICENSE AGREEMENT FOR TRIAL VERSION
# By installing the Product, You, as licensee, are entering into an agreement
# with Software AG, as licensor, with GENERAL TERMS as defined in Part A, as
# well as with terms set forth below (Part D). In case of conflicting terms
# between Part A and D, the terms of this Part D shall apply ("Evaluation)
# License Agreement"). If You do not agree to the terms of this agreement,
# You must immediately, and in any case before installation, destroy the
# Product and all copies of the Product in physical, electronic or other form.
# 
# THE LICENSE
# With this Evaluation License Agreement, Software AG grants You - free of charge
# - a non-exclusive license to use the Product and accompanying documentation on
# a single computer, on a workstation or on a single terminal within a network
# for evaluation and testing purposes for a time period defined below (see
# section License Validity). In no event may the Product be deployed or used
# for any commercial production purpose such as developing new applications or
# testing, supporting, maintaining, or reengineering of existing applications,
# unless You acquire a commercial license from Software AG and pay the applicable
# license fees. You may not pass on copies of the Product to any third party or
# transfer the Product by electronic means to other computers via a network. For
# multi-user hardware systems or networks, a separate license is required for
# each user or each workstation. You have the right to make one copy of the
# Product solely for archival and backup purposes. You may not decompile,
# disassemble, modify, decrypt, extract or otherwise reverse engineer, or
# make further copies of the Product or parts thereof. This Evaluation License
# Agreement, with the downloaded or otherwise provided and used authorization
# key, is proof of your entering into this agreement and You must retain it. This
# Evaluation License Agreement does not grant You the right to sublicense,
# transfer, rent, assign or lease the Product, in whole or in part.
# 
# THIRD PARTY RESTRICTIONS
# The Product is designed for general office use. It is not designed or
# intended for use in air traffic control, mass transit systems, critical
# medical purposes, the operation of nuclear facilities or any other use which
# could result in a high risk of safety or property damage. You warrant that
# You will not use the Product for such purposes.
# 
# LICENSE VALIDITY
# This Evaluation License Agreement is limited to a period no longer than
# ninety (90) days starting from the date of installation of the Product,
# or as defined in the license key file or in Part E below. The license might
# limit your use of the Product to certain features, platforms or restrictions
# in capacity or other limitations incorporated by default, by license key
# file or - if applicable - by definition in Part E below. You accept these
# limitations and will in no event bypass these.
# 
# COPYRIGHT
# Software AG or its affiliates are the sole owner of the industrial property
# rights and copyright to the Product and accompanying user documentation or
# have the respective distribution rights. References made in or on the Product
# to the copyright or to other industrial property rights must not be altered,
# deleted or obliterated in any manner.
# 
# CONFIDENTIALITY
# The Product is confidential and proprietary information of Software AG and
# its licensors, and may not be disclosed to third parties. You shall use
# such information only for the purpose of exercising the Evaluation License
# Agreement to the Product and shall disclose confidential and proprietary
# information only to your employees who require such information for the
# purpose stated above. You agree to take adequate steps to protect the Product
# from unauthorized disclosure or use.
# 
# LIMITED WARRANTY
# The Product is provided "as is" without any warranty whatsoever. You
# assume full responsibility for the selection of the Product to achieve your
# intended results and for the installation, use and results obtained from
# the Product. Any kind of support for the Software AG Product is explicitly
# excluded.
# 
# UPDATES AND MAINTENANCE
# This Evaluation License Agreement does not grant You any right to, license
# for or interest in any improvements, modifications, enhancements or updates
# to the Product and documentation or other support services. Such services
# are typically available under a Commercial License Agreement only. Any such
# arrangements shall be the subject of a separate written agreement.
# 
# LIMITATION OF LIABILITY
# Under no circumstances shall Software AG or its licensors be liable for
# any damages whatsoever (including, without limitation, damages for loss
# of business profits, work stoppage, loss of data or other financial loss)
# arising from the use of, or inability to use, this Product. In no event shall
# any liability of Software AG arising out of this agreement exceed the amount
# paid, if any, by You to Software AG hereunder.
# 
# TERMINATION
# This Evaluation License Agreement will terminate immediately without notice
# from Software AG if You fail to comply with any provision of this Evaluation
# License Agreement. Software AG reserves the right to terminate this agreement
# immediately for good cause, whereby good cause is understood as any gross
# breach of this agreement. Upon termination, You must immediately discontinue
# the use of the Product and destroy the Product and all copies of the Product
# in physical, electronic or other form.
# 
# EXPORT RESTRICTIONS
# You agree that U.S. export control law and other applicable export and import law provisions govern your use of the Software Applications and/or Technology, including technical assistance and technical data (as defined under �Technology� in the Definitions section of the EAR, �722.1); 
# You further agree not to download and/or otherwise export or re-export directly, or indirectly, any underlying download items (i.e. Software, Technology, any direct product thereof, or other information from the Licensed Software), except as stated explicitly in this Agreement and in full compliance with all applicable national and international export- and other laws and regulations, or not to use these items for any purpose prohibited by said laws, including, without limitation, nuclear, chemical, or biological weapons proliferation.
# You also agree to indemnify and hold harmless and defend SOFTWARE AG against any and all liability arising from, or relating to your breach of this Section.
# Software AG Employees: Under no circumstances is Software AG  staff authorized to download software for the purpose of distributing it to third parties. Software AG products are available to its employees for internal use or demonstration purposes only. 
# 
# MISCELLANEOUS
# The invalidity of any provision of this agreement shall not affect any other
# part of this agreement. This agreement represents the complete and exclusive
# statement concerning this Evaluation License Agreement between the parties. No
# modification or amendment of this agreement will be binding on any party
# unless acknowledged in writing by their duly authorized representatives. This
# agreement shall be governed and construed by the laws of the Federal Republic
# of Germany.
# 
# 
# PART E: PRODUCT SPECIFIC TERMS for Adabas, Natural and NaturalONE Community
# Editions
# (ADANATCOMv201001)
# 
# In paragraph "LICENSE VALIDITY" the first sentence shall be replaced by:
# 
# This Evaluation License Agreement is limited to a period defined in the
# license key file, or until terminated by either party.
# 
# In case of conflicting terms between this Part E and your license agreement,
# the terms of this Part E shall apply.
# 
# 
# PART E: PRODUCT SPECIFIC TERMS for Tamino
# (INSv200702)
# 
# List of Redistributable Programs for Tamino XML Server The product distribution
# contains programs that You may redistribute with your application. The names
# of these redistributable programs and their locations after Tamino XML Server
# has been installed are as follows ("<InstallDir>" refers to the Tamino XML
# Server installation directory):
# 
# Tamino API for Java (<InstallDir>/SDK/TaminoAPI4J)
# 
# HTTP Client API for JScript (<InstallDir>/SDK/JScriptAPI)
# 
# HTTP Client API for ActiveX (<InstallDir>/SDK/ActiveXAPI)
# 
# Tamino API for .NET (<InstallDir>/SDK/TaminoAPI4DotNET)
# 
# Tamino API for C (<InstallDir>/SDK/TaminoAPI4C)
# 
# 
# PART E: PRODUCT SPECIFIC TERMS for CentraSite
# (INMv200912)
# 
# E1 - Usage of WebDAV
# 
# Licensee of the CentraSite Community Edition may not use the CentraSite
# Repository via the WebDAV interface to store or extend data assets except
# through applications of CentraSite Community sponsors.
# 
# 
# E2 - Usage of Design GUI
# 
# Licensee of any CentraSite Edition may not use the integrated Application
# Designer's UI development components other than for the intended creation
# of CentraSite plug-ins.
# 
# E3 - Usage of Federation Capabilities
# 
# Generating a single, logical view on distributed CentraSite
# Registries/Repositories or other UDDI registries (Federation Capabilities)
# is exclusive to CentraSite ActiveSOA Edition licensees. Community Edition
# licensees are not entitled to use the built-in Federation Capabilities,
# which might not be (technically) available with future Community Edition
# updates and/or versions.
# 
# E4 - Plug-In for Amberpoint SOA Management System integration
# 
# Some parts of the separately deployable product add-on are designed to interact
# with and modify third party software packages upon installation or use.
# 
# In the course of this interaction the third party software, its setup and/or
# its security settings might be manipulated. The user has to create backups of
# the third party software and its files BEFORE performing any such interactions
# with this product package in order to be able to recover from any damage. The
# user has to check AFTER such action whether the performance and settings of
# the third party software are in accordance with his/her expectations.
# 
# Software AG and its licensors do not hold responsibility for any direct or
# consequential damages to third party software.
# 
# Please refer to the readme.txt and the user manual shipped with this product!
# 
# Software AG and its licensors reserve all rights at their sole discretion
# that a part or all of the features of this add-on feature set:
# 
# - might require manual migration of data to a new version;
# 
# - might become part of a separate product or an extended version for which
# You might not hold a license;
# 
# - might be discontinued.
# 
# PART E: PRODUCT SPECIFIC TERMS for Nirvana
# 
# E1 - Benchmarking 
# 
# It is a material term that you shall not use the Software for benchmarking or similar performance-related testing purposes without the express written consent of Software AG.
# 
# If Software AG consents to your using the Software for any benchmarking or similar performance-related testing purposes, you shall not publish or disclose to a third party the outcomes or results of any such exercise, or any information derived from the outcomes or results of such exercise, without the additional express written consent of Software AG. 
# 
# 
# END OF LEGAL NOTICES
# 
#  ------------------------------------------------------------------------
# Check to ensure that the installation env has been executed first
#

echo Setting up Environment Variables for Client Config @@CLIENT_CONFIG@@

BASEDIR=@@USER_MAGIC_FOLDER_5@@ ;export BASEDIR
INSTALLDIR=@@USER_INSTALL_DIR@@ ;export INSTALLDIR
RNAME=@@CLIENT_RNAME@@ ;export RNAME
LOGLEVEL=@@CLIENT_LOGLEVEL@@ ;export LOGLEVEL 

#
# Set the nirvana home environment
#
    NIRVANA_HOME=$INSTALLDIR;export NIRVANA_HOME
#
# Add the bin into the path
#
    PATH=$INSTALLDIR/cplus:$BASEDIR:$PATH;export PATH

#
# Set up the LD_LIBRARY_PATH for the sample apps
#

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$INSTALLDIR/cplus/lib/
export DYLD_FALLBACK_LIBRARY_PATH=$INSTALLDIR/cplus/lib/


#
# Set up the libraries for linking and running
#

ldconfig -n $INSTALLDIR/cplus/lib/

$SHELL
