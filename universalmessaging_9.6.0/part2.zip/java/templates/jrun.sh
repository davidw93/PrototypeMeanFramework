#!/bin/sh
#  ----------------------------------------------------------------------------------
#
#  PCB Systems Limited License Version 1.1
#  Copyright � PCB Systems Limited. All rights reserved
#
#  In the event that you should download or otherwise use this software
#  ( the "Software" ) you hereby acknowledge and agree that:
#
#  1. The Software is the property of PCB Systems Limited: Title, Copyright and all
#  other proprietary rights, interest and benefit in and to the Software is and
#  shall be owned by PCB Systems Limited;
#
#  2. You will not make copies of the Software whatsoever other than, if you should
#  so wish, a single copy for archival purposes only;
#
#  3. You will not modify, reverse assemble, decompile, reverse engineer or otherwise
#  translate the Software;
#
#  4. You will not redistribute, copy, forward electronically or circulate the Software
#  to any person for any purpose whatsoever without the prior written consent of
#  PCB Systems Limited;
#
#  5. You will not charge for, market or provide any managed service or product that
#  is based upon or includes the Software or any variant of it; and
#
#  6. You will not use the Software for any purpose apart from your own personal,
#  noncommercial and lawful use;
#
#  You hereby agree that the software is used by you on an "as is" basis, without
#  warranty of any kind. PCB Systems Limited hereby expressly disclaim all warranties
#  and conditions, either expressed or implied, including but not limited to any
#  implied warranties or conditions or merchantability and fitness for a particular
#  purpose.
#
#  You agree that you are solely responsible for determining the appropriateness of
#  using the Software and assume all risks associated with it including but not
#  limited to the risks of program errors, damage to or loss of of data, programs or
#  equipment and unavailability or interruption of operations.
#
#  PCB Systems Limited will not be liable for any direct damages or for any, special,
#  incidental or indirect damages or for any economic consequential damages ( including
#  lost profits or savings ), or any damage howsoever arising.
#
#  ----------------------------------------------------------------------------------
#
# Set the Java command line for use by the scripts
#
    JRUN=" java -DLOGLEVEL=$LOGLEVEL ";export JRUN
    if [ ${KEYSTORE:-noval} != noval ]; then
	JRUN=$JRUN"-Djavax.net.ssl.keyStore=$CKEYSTORE ";export JRUN
	JRUN=$JRUN"-Djavax.net.ssl.keyStorePassword=$KEYSTOREPASSWD ";export JRUN
	JRUN=$JRUN"-Djava.protocol.handler.pkgs=com.sun.net.ssl.internal.www.protocol ";export JRUN
	JRUN=$JRUN"-Djavax.net.ssl.trustStore=$CAKEYSTORE";export JRUN
	JRUN=$JRUN"-Djava.protocol.handler.pkgs=com.sun.net.ssl.internal.www.protocol"; export JRUN

#
# Uncomment the following line if you want verbose debugging for SSL
#        export JRUN;JRUN=$JRUN"-Djavax.net.debug=ssl,handshake,data "
    fi


#
# Setup for proxy servers
#
    if [ ${HPROXY:-noval} != noval ]; then
	JRUN=$JRUN "-DHPROXY=$HPROXY ";export JRUN
        if [ ${HAUTH:-noval} != noval ]; then
            JRUN=$JRUN "-DHAUTH=$HAUTH ";export JRUN
	fi
    fi

#
# Setup for custom client side JVM heap sizes
#
#    if [ ${CMINMEM:-noval} != noval ]; then
#	JRUN=$JRUN "-Xms$CMINMEM -Xmx$CMAXMEM ";export JRUN
#    fi
